<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This project is a React-based web application migrated from a static HTML/CSS/JS site. Please generate React components for login, registration, and dashboard functionality, and adapt existing CSS for use with React components.
